/**
 * Playground API DevTools Companion — Background Service Worker
 * Manages dynamic declarativeNetRequest rules to inject simulation headers.
 */

const RULE_ID = 1001;

// Default initial state
const defaultState = {
  enabled: true,
  identityToken: '',
  delay: 0,
  status: 0,
  chaos: 0,
  role: '',
  scopes: '',
  enforceRbac: false
};

// Update declarativeNetRequest header modification rules
async function updateNetRules(state) {
  if (!chrome.declarativeNetRequest) return;

  const requestHeaders = [];

  if (state.enabled) {
    if (state.identityToken) {
      requestHeaders.push({
        header: 'X-Playground-Identity',
        operation: 'set',
        value: state.identityToken
      });
    }

    if (state.delay && state.delay > 0) {
      requestHeaders.push({
        header: 'X-Simulate-Delay',
        operation: 'set',
        value: String(state.delay)
      });
    }

    if (state.status && state.status > 0) {
      requestHeaders.push({
        header: 'X-Simulate-Status',
        operation: 'set',
        value: String(state.status)
      });
    }

    if (state.chaos && state.chaos > 0) {
      requestHeaders.push({
        header: 'X-Simulate-Chaos',
        operation: 'set',
        value: String(state.chaos)
      });
    }

    if (state.role) {
      requestHeaders.push({
        header: 'X-Simulate-Role',
        operation: 'set',
        value: state.role
      });
    }

    if (state.scopes) {
      requestHeaders.push({
        header: 'X-Simulate-Scopes',
        operation: 'set',
        value: state.scopes
      });
    }

    if (state.enforceRbac) {
      requestHeaders.push({
        header: 'X-Enforce-RBAC',
        operation: 'set',
        value: 'true'
      });
    }
  }

  const removeRuleIds = [RULE_ID];
  const addRules = [];

  if (requestHeaders.length > 0) {
    addRules.push({
      id: RULE_ID,
      priority: 1,
      action: {
        type: 'modifyHeaders',
        requestHeaders
      },
      condition: {
        urlFilter: '*',
        initiatorDomains: [],
        domains: ['localhost', '127.0.0.1', 'playground.nileslabs.com'],
        resourceTypes: ['xmlhttprequest', 'other']
      }
    });
  }

  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds,
      addRules
    });
  } catch (err) {
    console.error('Failed to update declarativeNetRequest rules:', err);
  }
}

// Listen for state changes from DevTools panel
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'UPDATE_SIMULATION_STATE') {
    chrome.storage.local.set({ simulationState: message.payload }, () => {
      updateNetRules(message.payload);
      sendResponse({ success: true });
    });
    return true;
  }

  if (message.type === 'GET_SIMULATION_STATE') {
    chrome.storage.local.get(['simulationState'], (result) => {
      sendResponse({ state: result.simulationState || defaultState });
    });
    return true;
  }
});

// Restore rules on service worker startup
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['simulationState'], (result) => {
    const state = result.simulationState || defaultState;
    updateNetRules(state);
  });
});
