/**
 * Playground API DevTools Panel Initializer
 */
chrome.devtools.panels.create(
  "Playground API",
  "icons/icon16.png",
  "panel.html",
  function(panel) {
    console.log("Playground API DevTools panel created successfully.");
  }
);
