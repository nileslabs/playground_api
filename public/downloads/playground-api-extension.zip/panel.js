/**
 * Playground API DevTools Panel Logic
 */

// State Object
let state = {
  enabled: true,
  identityToken: '',
  delay: 0,
  status: 0,
  chaos: 0,
  role: '',
  scopes: '',
  enforceRbac: false
};

// DOM Elements
const masterToggle = document.getElementById('masterToggle');
const masterStatusLabel = document.getElementById('masterStatusLabel');
const identityTokenInput = document.getElementById('identityTokenInput');
const detectIdentityBtn = document.getElementById('detectIdentityBtn');
const copyTokenBtn = document.getElementById('copyTokenBtn');
const delaySlider = document.getElementById('delaySlider');
const delayValueBadge = document.getElementById('delayValueBadge');
const presetButtons = document.querySelectorAll('.preset-btn');
const statusSelect = document.getElementById('statusSelect');
const chaosSlider = document.getElementById('chaosSlider');
const chaosValueBadge = document.getElementById('chaosValueBadge');
const roleButtons = document.querySelectorAll('.role-btn');
const resetSandboxBtn = document.getElementById('resetSandboxBtn');
const exportSnapshotBtn = document.getElementById('exportSnapshotBtn');
const actionStatusMessage = document.getElementById('actionStatusMessage');
const requestLogStream = document.getElementById('requestLogStream');
const clearLogsBtn = document.getElementById('clearLogsBtn');

// Sync state to background service worker
function syncState() {
  if (chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({
      type: 'UPDATE_SIMULATION_STATE',
      payload: state
    });
  }
}

// Update UI to match current state
function renderState() {
  masterToggle.checked = state.enabled;
  masterStatusLabel.textContent = state.enabled ? 'Active' : 'Disabled';
  masterStatusLabel.style.color = state.enabled ? 'var(--accent-green)' : 'var(--text-muted)';

  identityTokenInput.value = state.identityToken || '';

  delaySlider.value = state.delay || 0;
  delayValueBadge.textContent = `${state.delay || 0} ms`;

  presetButtons.forEach(btn => {
    const d = parseInt(btn.getAttribute('data-delay'), 10);
    btn.classList.toggle('active', d === (state.delay || 0));
  });

  statusSelect.value = String(state.status || 0);

  chaosSlider.value = state.chaos || 0;
  chaosValueBadge.textContent = `${Math.round((state.chaos || 0) * 100)}%`;

  roleButtons.forEach(btn => {
    const r = btn.getAttribute('data-role');
    btn.classList.toggle('active', r === (state.role || ''));
  });
}

// Detect identity token from active inspected page
function detectIdentity() {
  if (!chrome.devtools || !chrome.devtools.inspectedWindow) return;

  chrome.devtools.inspectedWindow.eval(
    `(function() {
      var cookieMatch = document.cookie.match(/pg_identity=([^;]+)/);
      var ls = localStorage.getItem('pg_identity');
      return (cookieMatch && cookieMatch[1]) || ls || '';
    })()`,
    (result, isException) => {
      if (!isException && result) {
        state.identityToken = result;
        identityTokenInput.value = result;
        showStatus('Identity detected from page!', 'var(--accent-green)');
        syncState();
      } else {
        showStatus('No active identity cookie found on page.', 'var(--accent-amber)');
      }
    }
  );
}

function showStatus(text, color = 'var(--text-main)') {
  actionStatusMessage.textContent = text;
  actionStatusMessage.style.color = color;
  setTimeout(() => {
    actionStatusMessage.textContent = '';
  }, 3500);
}

// Add entry to request interceptor log
function addLogEntry(url, headersApplied) {
  const empty = requestLogStream.querySelector('.empty-log');
  if (empty) empty.remove();

  const item = document.createElement('div');
  item.className = 'log-item';
  const cleanUrl = url.replace(/^https?:\/\/[^/]+/, '');
  const time = new Date().toLocaleTimeString();

  item.innerHTML = `
    <span class="log-tag">[SIMULATED]</span>
    <span style="color: var(--text-main); font-weight: 500;">${cleanUrl}</span>
    <span style="color: var(--text-muted);">${time}</span>
  `;

  requestLogStream.prepend(item);

  // Keep max 20 logs
  while (requestLogStream.children.length > 20) {
    requestLogStream.removeChild(requestLogStream.lastChild);
  }
}

// Initialize Event Handlers
function setupEvents() {
  masterToggle.addEventListener('change', (e) => {
    state.enabled = e.target.checked;
    renderState();
    syncState();
  });

  detectIdentityBtn.addEventListener('click', detectIdentity);

  copyTokenBtn.addEventListener('click', () => {
    if (state.identityToken) {
      navigator.clipboard.writeText(state.identityToken);
      showStatus('Token copied to clipboard!', 'var(--accent-green)');
    }
  });

  delaySlider.addEventListener('input', (e) => {
    state.delay = parseInt(e.target.value, 10);
    renderState();
    syncState();
  });

  presetButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      state.delay = parseInt(btn.getAttribute('data-delay'), 10);
      renderState();
      syncState();
    });
  });

  statusSelect.addEventListener('change', (e) => {
    state.status = parseInt(e.target.value, 10);
    renderState();
    syncState();
  });

  chaosSlider.addEventListener('input', (e) => {
    state.chaos = parseFloat(e.target.value);
    renderState();
    syncState();
  });

  roleButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      state.role = btn.getAttribute('data-role');
      state.enforceRbac = state.role !== '';
      renderState();
      syncState();
    });
  });

  resetSandboxBtn.addEventListener('click', () => {
    showStatus('Resetting sandbox...', 'var(--accent-purple)');
    if (chrome.devtools && chrome.devtools.inspectedWindow) {
      chrome.devtools.inspectedWindow.eval(
        `(function() {
          var cookieMatch = document.cookie.match(/pg_identity=([^;]+)/);
          var token = (cookieMatch && cookieMatch[1]) || localStorage.getItem('pg_identity') || '';
          return fetch('/api/v1/session/reset', {
            method: 'DELETE',
            headers: token ? { 'X-Playground-Identity': token } : {},
            credentials: 'include'
          }).then(function(r) { return r.json(); });
        })()`,
        (result, isException) => {
          if (!isException && result) {
            showStatus('Sandbox successfully reset to baseline!', 'var(--accent-green)');
            // Trigger page reload
            chrome.devtools.inspectedWindow.reload();
          } else {
            showStatus('Sandbox reset completed.', 'var(--accent-green)');
          }
        }
      );
    }
  });

  exportSnapshotBtn.addEventListener('click', () => {
    if (chrome.devtools && chrome.devtools.inspectedWindow) {
      chrome.devtools.inspectedWindow.eval(
        `(function() {
          var cookieMatch = document.cookie.match(/pg_identity=([^;]+)/);
          var token = (cookieMatch && cookieMatch[1]) || localStorage.getItem('pg_identity') || '';
          return fetch('/api/v1/session/export', {
            headers: token ? { 'X-Playground-Identity': token } : {},
            credentials: 'include'
          }).then(function(r) { return r.json(); });
        })()`,
        (result, isException) => {
          if (!isException && result) {
            const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `playground-sandbox-snapshot-${Date.now()}.json`;
            a.click();
            showStatus('Snapshot JSON exported!', 'var(--accent-green)');
          }
        }
      );
    }
  });

  clearLogsBtn.addEventListener('click', () => {
    requestLogStream.innerHTML = '<div class="empty-log">No requests intercepted yet. Active simulation headers are applied to all matching requests.</div>';
  });

  // Listen to network events in DevTools
  if (chrome.devtools && chrome.devtools.network) {
    chrome.devtools.network.onRequestFinished.addListener((request) => {
      const url = request.request.url;
      if (url.includes('/api/v1') || url.includes('/posts') || url.includes('/users') || url.includes('/todos') || url.includes('/comments')) {
        if (state.enabled && (state.delay > 0 || state.status > 0 || state.chaos > 0 || state.role !== '')) {
          addLogEntry(url);
        }
      }
    });
  }
}

// Initial Load
document.addEventListener('DOMContentLoaded', () => {
  if (chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: 'GET_SIMULATION_STATE' }, (res) => {
      if (res && res.state) {
        state = { ...state, ...res.state };
      }
      renderState();
      detectIdentity();
    });
  } else {
    renderState();
  }

  setupEvents();
});
