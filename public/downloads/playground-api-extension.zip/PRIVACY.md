# Privacy Policy & Single Purpose Statement — Playground API DevTools Companion

## Single Purpose Statement
The **Playground API DevTools Companion** extension is designed solely for web developers to inspect and simulate HTTP requests, network delays, error responses, and mock sandbox states when testing frontend applications against the Playground API (`localhost`, `127.0.0.1`, and `*.nileslabs.com`).

---

## Data Collection & Privacy Disclosures

1. **Zero Data Collection**:
   - This extension **does not collect, transmit, store, or sell any personal data, analytics, browsing history, or user identifiable information**.
   - No tracking beacons, analytics telemetry, or third-party tracking scripts are included.

2. **100% Client-Side Local Storage**:
   - All developer simulation preferences (such as selected latency milliseconds, error status codes, and active test persona roles) are stored exclusively in your browser's local storage (`chrome.storage.local`).
   - Preferences never leave your local machine.

3. **Permission Justification**:
   - **`declarativeNetRequest`**: Strictly used to inject developer simulation HTTP request headers (`X-Simulate-Delay`, `X-Simulate-Status`, `X-Simulate-Chaos`, `X-Simulate-Role`, `X-Playground-Identity`) into outgoing requests targeting development environments (`localhost`, `127.0.0.1`, and `playground.nileslabs.com`).
   - **`storage`**: Used solely to persist your local simulation preferences between browser sessions.
   - **`devtools_page`**: Required to mount the "Playground API" tab panel inside Chrome / Edge / Brave DevTools.

---

## Contact & Open Source
- **Website**: https://playground.nileslabs.com/docs/devtools
- **Support**: support@nileslabs.com
- **Repository**: https://github.com/nileslabs/playground_api
